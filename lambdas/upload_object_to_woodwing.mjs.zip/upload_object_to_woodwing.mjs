
  export const handler = async (event, context) => {

    const body = JSON.parse(event.Records[0].body);

    console.log(body);
    try{
        console.log(body.Records[0].s3.object.key);
    }catch(e)
    {

    }
    console.log(event);
  };